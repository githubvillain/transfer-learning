# Face-Recognition-using-Transfer-Learning
Transfer learning is a machine learning method where a model developed for a task is reused as the starting point for a model on a second task.

In this Task I have used Pretrained VGG16 model to recognise face using Transfer learning. I did this task in 3 steps : 

Collecting Image Samples
Using Transfer Learning for Training model
Testing 
